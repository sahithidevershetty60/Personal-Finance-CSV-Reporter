import csv
import json
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from datetime import date, datetime
import logging
from service_manager import ServiceManager

ROOT = Path(__file__).parent
DATA_DIR = ROOT / "data"
JSON_FILE = DATA_DIR / "services.json"
CSV_FILE = DATA_DIR / "services.csv"
FIELDS = ["id", "bike_name", "service_date", "odometer_km", "category",
          "notes", "next_service_km", "next_service_date", "current_odometer_km"]


def setup_logging():
    log_dir = ROOT / "logs"
    log_dir.mkdir(exist_ok=True)
    logging.basicConfig(
        filename=log_dir / "bike_service.log",
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        encoding="utf-8",
    )

manager = ServiceManager(DATA_DIR / "bike_service.db")

def ensure_files():
    DATA_DIR.mkdir(exist_ok=True)
    manager.initialize()

def load_data():
    try:
        return manager.list_records()
    except Exception:
        logging.exception("Could not load service records")
        messagebox.showerror("Storage error", "Could not read the SQLite database. Check logs/bike_service.log.")
        return []

def save_data():
    try:
        manager.replace_all(records)
        logging.info("Saved %s service records", len(records))
    except Exception:
        logging.exception("Could not save service records")
        messagebox.showerror("Storage error", "Could not save records. Check logs/bike_service.log.")

def valid_date(value, optional=False):
    if optional and not value.strip():
        return True
    try:
        parsed = datetime.strptime(value.strip(), "%Y-%m-%d").date()
        return parsed <= date.today()
    except ValueError:
        return False

def as_int(value, label, allow_zero=True):
    try:
        number = int(value)
        if number < (0 if allow_zero else 1):
            raise ValueError
        return number
    except ValueError:
        raise ValueError(f"{label} must be a valid " + ("non-negative" if allow_zero else "positive") + " whole number.")

class ServiceDialog(tk.Toplevel):
    def __init__(self, parent, title, item=None):
        super().__init__(parent)
        self.title(title)
        self.resizable(False, False)
        self.result = None
        self.transient(parent)
        self.grab_set()
        item = item or {}
        self.vars = {}
        fields = [
            ("bike_name", "Bike name / model", item.get("bike_name", "")),
            ("service_date", "Service date (YYYY-MM-DD)", item.get("service_date", date.today().isoformat())),
            ("odometer_km", "Odometer at service (km)", str(item.get("odometer_km", ""))),
            ("category", "Service category", item.get("category", "General service")),
            ("notes", "Maintenance notes", item.get("notes", "")),
            ("next_service_km", "Next service at (km; 0 = unset)", str(item.get("next_service_km", 0))),
            ("next_service_date", "Next service date (YYYY-MM-DD; optional)", item.get("next_service_date", "")),
            ("current_odometer_km", "Current odometer (km; optional)", str(item.get("current_odometer_km", ""))),
        ]
        body = ttk.Frame(self, padding=14)
        body.grid(row=0, column=0, sticky="nsew")
        for row, (key, label, value) in enumerate(fields):
            ttk.Label(body, text=label).grid(row=row, column=0, sticky="w", padx=(0, 12), pady=5)
            var = tk.StringVar(value=value)
            self.vars[key] = var
            ttk.Entry(body, textvariable=var, width=36).grid(row=row, column=1, pady=5)
        buttons = ttk.Frame(body)
        buttons.grid(row=len(fields), column=0, columnspan=2, sticky="e", pady=(12, 0))
        ttk.Button(buttons, text="Cancel", command=self.destroy).pack(side="right", padx=5)
        ttk.Button(buttons, text="Save", command=self.submit).pack(side="right")
        self.bind("<Return>", lambda _e: self.submit())
        self.wait_visibility()
        self.focus_set()

    def submit(self):
        values = {key: var.get().strip() for key, var in self.vars.items()}
        if not values["bike_name"] or not values["category"] or not values["notes"]:
            messagebox.showerror("Validation", "Bike name, category, and notes cannot be blank.", parent=self)
            return
        if not valid_date(values["service_date"]):
            messagebox.showerror("Validation", "Service date must be a valid date in YYYY-MM-DD format and cannot be in the future.", parent=self)
            return
        if not valid_date(values["next_service_date"], optional=True):
            messagebox.showerror("Validation", "Next service date must use YYYY-MM-DD and cannot be in the future.", parent=self)
            return
        try:
            values["odometer_km"] = as_int(values["odometer_km"], "Odometer", False)
            values["next_service_km"] = as_int(values["next_service_km"], "Next service odometer")
            values["current_odometer_km"] = as_int(values["current_odometer_km"] or "0", "Current odometer")
        except ValueError as exc:
            messagebox.showerror("Validation", str(exc), parent=self)
            return
        if values["current_odometer_km"] and values["current_odometer_km"] < values["odometer_km"]:
            messagebox.showerror("Validation", "Current odometer cannot be lower than the service odometer.", parent=self)
            return
        self.result = values
        self.destroy()

class BikeServiceApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Bike Service Log Pro 2.0")
        self.geometry("1120x720")
        self.minsize(900, 600)
        self.configure(bg="#f3f6fb")
        self.style = ttk.Style(self)
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass
        self.style.configure("Treeview", rowheight=29, font=("Segoe UI", 9))
        self.style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))
        self.style.configure("Title.TLabel", font=("Segoe UI", 20, "bold"), foreground="#16345f")
        self.style.configure("Sub.TLabel", font=("Segoe UI", 9), foreground="#64748b")
        self.style.configure("Card.TLabelframe", padding=12)
        self.build_ui()
        self.refresh()

    def build_ui(self):
        header = ttk.Frame(self, padding=(18, 16))
        header.pack(fill="x")
        ttk.Label(header, text="BIKE SERVICE LOG PRO 2.0", style="Title.TLabel").pack(anchor="w")
        ttk.Label(header, text="Maintenance history • service reminders • reports", style="Sub.TLabel").pack(anchor="w", pady=(3, 0))

        cards = ttk.Frame(self, padding=(18, 0))
        cards.pack(fill="x")
        self.metrics = {}
        for key, label in [("records", "TOTAL RECORDS"), ("bikes", "BIKES TRACKED"), ("due", "DUE / OVERDUE"), ("average", "AVG. ODOMETER")]:
            frame = ttk.LabelFrame(cards, text=label, style="Card.TLabelframe")
            frame.pack(side="left", fill="x", expand=True, padx=(0, 10))
            value = ttk.Label(frame, text="0", font=("Segoe UI", 18, "bold"), foreground="#1d4ed8")
            value.pack(anchor="w")
            self.metrics[key] = value

        toolbar = ttk.Frame(self, padding=(18, 14, 18, 8))
        toolbar.pack(fill="x")
        ttk.Button(toolbar, text="+ Add record", command=self.add_record).pack(side="left")
        ttk.Button(toolbar, text="Edit selected", command=self.edit_record).pack(side="left", padx=6)
        ttk.Button(toolbar, text="Delete selected", command=self.delete_record).pack(side="left")
        ttk.Button(toolbar, text="Service alerts", command=self.show_alerts).pack(side="left", padx=6)
        ttk.Button(toolbar, text="Export CSV", command=self.export_csv).pack(side="right")
        ttk.Button(toolbar, text="Import CSV", command=self.import_csv).pack(side="right", padx=6)

        searchbar = ttk.Frame(self, padding=(18, 0, 18, 8))
        searchbar.pack(fill="x")
        ttk.Label(searchbar, text="Search:").pack(side="left")
        self.search_var = tk.StringVar()
        search = ttk.Entry(searchbar, textvariable=self.search_var, width=38)
        search.pack(side="left", padx=8)
        search.bind("<KeyRelease>", lambda _e: self.refresh())
        ttk.Button(searchbar, text="Clear", command=self.clear_search).pack(side="left")
        ttk.Label(searchbar, text="Search by bike, category, date or notes", style="Sub.TLabel").pack(side="left", padx=12)

        table_frame = ttk.Frame(self, padding=(18, 0, 18, 12))
        table_frame.pack(fill="both", expand=True)
        cols = ("id", "bike", "date", "odo", "category", "next_km", "next_date", "status")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings", selectmode="browse")
        headings = {"id":"ID", "bike":"Bike", "date":"Service date", "odo":"Odometer", "category":"Category",
                    "next_km":"Next service km", "next_date":"Next service date", "status":"Status"}
        widths = {"id":45, "bike":175, "date":100, "odo":95, "category":135, "next_km":115, "next_date":125, "status":110}
        for col in cols:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=widths[col], anchor="w")
        yscroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        xscroll = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)
        self.tree.tag_configure("overdue", foreground="#b91c1c")
        self.tree.tag_configure("soon", foreground="#b45309")
        self.tree.bind("<Double-1>", lambda _e: self.edit_record())

        footer = ttk.Frame(self, padding=(18, 6))
        footer.pack(fill="x")
        ttk.Label(footer, text="SQLite database • automated logging • service reminders • CSV / Markdown reports", style="Sub.TLabel").pack(side="left")
        ttk.Button(footer, text="Export Markdown report", command=self.export_markdown).pack(side="right")

    def status_for(self, item):
        return manager.status_for(item)

    def refresh(self):
        global records
        records = load_data()
        term = self.search_var.get().strip().lower() if hasattr(self, "search_var") else ""
        visible = [r for r in records if term in " ".join(str(r.get(k, "")) for k in FIELDS).lower()]
        for row in self.tree.get_children():
            self.tree.delete(row)
        for r in sorted(visible, key=lambda x: x.get("service_date", ""), reverse=True):
            status = self.status_for(r)
            tag = "overdue" if "OVERDUE" in status else ("soon" if "SOON" in status else "")
            self.tree.insert("", "end", iid=str(r["id"]), values=(
                r["id"], r["bike_name"], r["service_date"], f'{r["odometer_km"]:,} km',
                r["category"], f'{int(r.get("next_service_km") or 0):,}' if r.get("next_service_km") else "—",
                r.get("next_service_date") or "—", status), tags=(tag,))
        due_count = sum("OVERDUE" in self.status_for(r) or "SOON" in self.status_for(r) for r in records)
        avg = sum(int(r.get("odometer_km", 0)) for r in records) / len(records) if records else 0
        self.metrics["records"].configure(text=str(len(records)))
        self.metrics["bikes"].configure(text=str(len({r.get("bike_name") for r in records})))
        self.metrics["due"].configure(text=str(due_count))
        self.metrics["average"].configure(text=f"{avg:,.0f} km")

    def selected(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showinfo("Select a record", "Please select a record first.")
            return None
        record_id = int(selection[0])
        return next((r for r in records if int(r["id"]) == record_id), None)

    def add_record(self):
        dialog = ServiceDialog(self, "Add service record")
        self.wait_window(dialog)
        if dialog.result:
            item = dialog.result
            item["id"] = max([int(r.get("id", 0)) for r in records], default=0) + 1
            records.append(item)
            save_data()
            logging.info("Added service record for %s", item["bike_name"])
            self.refresh()

    def edit_record(self):
        old = self.selected()
        if not old:
            return
        dialog = ServiceDialog(self, "Edit service record", old)
        self.wait_window(dialog)
        if dialog.result:
            old.update(dialog.result)
            save_data()
            logging.info("Updated service record #%s", old["id"])
            self.refresh()

    def delete_record(self):
        old = self.selected()
        if not old:
            return
        if messagebox.askyesno("Confirm delete", f'Delete service record #{old["id"]} for {old["bike_name"]}?'):
            records.remove(old)
            save_data()
            logging.info("Deleted service record #%s", old["id"])
            self.refresh()

    def clear_search(self):
        self.search_var.set("")
        self.refresh()

    def show_alerts(self):
        alerts = []
        for r in records:
            status = self.status_for(r)
            if status != "OK":
                alerts.append(f'• {r["bike_name"]} — {status} | next service: {r.get("next_service_date") or "date not set"} | {r.get("next_service_km") or "km not set"} km')
        messagebox.showinfo("Service alerts", "\n".join(alerts) if alerts else "No upcoming or overdue services.")

    def export_csv(self):
        path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")], initialfile="bike_service_report.csv")
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(records)
        messagebox.showinfo("Export complete", f"CSV report saved:\n{path}")

    def import_csv(self):
        path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if not path:
            return
        imported, skipped = 0, 0
        try:
            with open(path, newline="", encoding="utf-8-sig") as f:
                for row in csv.DictReader(f):
                    try:
                        if not row.get("bike_name") or not valid_date(row.get("service_date", "")):
                            skipped += 1
                            continue
                        row["id"] = max([int(r.get("id", 0)) for r in records], default=0) + 1
                        for key in ("odometer_km", "next_service_km", "current_odometer_km"):
                            row[key] = int(row.get(key) or 0)
                        for key in ("category", "notes", "next_service_date"):
                            row[key] = row.get(key, "")
                        records.append({k: row.get(k, "") for k in FIELDS} | {"id": row["id"]})
                        imported += 1
                    except (ValueError, TypeError):
                        skipped += 1
            save_data()
            self.refresh()
            messagebox.showinfo("Import complete", f"Imported: {imported}\nSkipped invalid rows: {skipped}")
        except (OSError, csv.Error) as exc:
            messagebox.showerror("Import failed", str(exc))

    def export_markdown(self):
        path = filedialog.asksaveasfilename(defaultextension=".md", filetypes=[("Markdown", "*.md")], initialfile="bike_service_report.md")
        if not path:
            return
        lines = ["# Bike Service Log Report", "", f"Generated: {date.today()}", "", f"Total records: {len(records)}", "",
                 "| ID | Bike | Date | Odometer | Category | Status |", "|---:|---|---|---:|---|---|"]
        for r in records:
            lines.append(f'| {r["id"]} | {r["bike_name"]} | {r["service_date"]} | {r["odometer_km"]} km | {r["category"]} | {self.status_for(r)} |')
        Path(path).write_text("\n".join(lines), encoding="utf-8")
        messagebox.showinfo("Export complete", f"Markdown report saved:\n{path}")

if __name__ == "__main__":
    setup_logging()
    ensure_files()
    records = load_data()
    app = BikeServiceApp()
    try:
        app.mainloop()
    except Exception:
        logging.exception("Unhandled application error")
        raise
