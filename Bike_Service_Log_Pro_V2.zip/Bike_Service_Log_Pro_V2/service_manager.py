
"""Business and persistence layer for Bike Service Log Pro."""
import sqlite3
from datetime import date, datetime
from pathlib import Path

FIELDS = ("id", "bike_name", "service_date", "odometer_km", "category",
          "notes", "next_service_km", "next_service_date", "current_odometer_km")

class ServiceManager:
    def __init__(self, database_path):
        self.database_path = Path(database_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    def connect(self):
        connection = sqlite3.connect(self.database_path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    def initialize(self):
        with self.connect() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS service_records (
                    id INTEGER PRIMARY KEY,
                    bike_name TEXT NOT NULL,
                    service_date TEXT NOT NULL,
                    odometer_km INTEGER NOT NULL CHECK(odometer_km >= 0),
                    category TEXT NOT NULL,
                    notes TEXT NOT NULL,
                    next_service_km INTEGER NOT NULL DEFAULT 0 CHECK(next_service_km >= 0),
                    next_service_date TEXT NOT NULL DEFAULT '',
                    current_odometer_km INTEGER NOT NULL DEFAULT 0 CHECK(current_odometer_km >= 0)
                )
            """)
            con.execute("CREATE INDEX IF NOT EXISTS idx_service_bike ON service_records(bike_name)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_service_date ON service_records(service_date)")
            count = con.execute("SELECT COUNT(*) FROM service_records").fetchone()[0]
            # Migrate the bundled JSON data once, without overwriting an existing database.
            legacy = self.database_path.parent / "services.json"
            if count == 0 and legacy.exists():
                import json
                try:
                    items = json.loads(legacy.read_text(encoding="utf-8"))
                    for item in items if isinstance(items, list) else []:
                        values = [item.get(k, 0 if k.endswith("_km") or k == "id" else "") for k in FIELDS]
                        con.execute(
                            "INSERT OR IGNORE INTO service_records VALUES (?,?,?,?,?,?,?,?,?)", values
                        )
                except (OSError, ValueError, TypeError):
                    pass

    def list_records(self):
        with self.connect() as con:
            return [dict(row) for row in con.execute(
                "SELECT * FROM service_records ORDER BY service_date DESC, id DESC"
            ).fetchall()]

    def replace_all(self, records):
        with self.connect() as con:
            con.execute("DELETE FROM service_records")
            con.executemany(
                "INSERT INTO service_records VALUES (?,?,?,?,?,?,?,?,?)",
                [[r.get(k, 0 if k.endswith("_km") or k == "id" else "") for k in FIELDS] for r in records]
            )

    @staticmethod
    def status_for(item, today=None):
        today = today or date.today()
        due_date = item.get("next_service_date", "")
        current = int(item.get("current_odometer_km") or 0)
        next_km = int(item.get("next_service_km") or 0)
        if due_date:
            try:
                parsed = datetime.strptime(due_date, "%Y-%m-%d").date()
                if parsed <= today:
                    return "OVERDUE"
                if (parsed - today).days <= 14:
                    return "DUE SOON"
            except ValueError:
                pass
        if current and next_km and current >= next_km:
            return "KM OVERDUE"
        if current and next_km and 0 <= next_km - current <= 500:
            return "KM SOON"
        return "OK"
