
# Bike Service Log Pro 2.0

Desktop bike-maintenance manager built with Python and Tkinter.

## What's improved
- SQLite persistence with indexed bike-name and service-date columns.
- One-time migration of the bundled `data/services.json` into SQLite.
- Separate `ServiceManager` business/data layer.
- File-based application logging in `logs/bike_service.log`.
- Automated unit tests for service status and database persistence.
- Existing Tkinter CRUD, search, alerts, CSV import/export and Markdown report.

## Run on Windows
1. Extract the ZIP.
2. Open PowerShell in the `Bike_Service_Log_Pro_V2` folder (the folder containing `main.py`).
3. Run `python main.py`.

Tkinter and SQLite are included with standard Python installations. The GUI itself needs no pip packages.

## Run tests
```powershell
python -m pip install -r requirements.txt
python -m pytest -q
```

## Data and logs
- Database: `data/bike_service.db`
- One-time migration source: `data/services.json`
- Application log: `logs/bike_service.log`

Keep the database file when moving the project. Back it up before manual edits.
