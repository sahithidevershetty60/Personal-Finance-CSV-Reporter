
from datetime import date, timedelta
from service_manager import ServiceManager

def sample():
    return {
        "id": 1, "bike_name": "Honda Activa", "service_date": "2026-01-01",
        "odometer_km": 1000, "category": "Engine oil", "notes": "Changed oil",
        "next_service_km": 2000, "next_service_date": "",
        "current_odometer_km": 1500,
    }

def test_status_ok():
    assert ServiceManager.status_for(sample(), today=date(2026, 1, 1)) == "OK"

def test_km_due_soon():
    item = sample()
    item["current_odometer_km"] = 1800
    assert ServiceManager.status_for(item, today=date(2026, 1, 1)) == "KM SOON"

def test_km_overdue():
    item = sample()
    item["current_odometer_km"] = 2100
    assert ServiceManager.status_for(item, today=date(2026, 1, 1)) == "KM OVERDUE"

def test_date_overdue():
    item = sample()
    item["next_service_date"] = "2025-12-31"
    assert ServiceManager.status_for(item, today=date(2026, 1, 1)) == "OVERDUE"

def test_database_round_trip(tmp_path):
    manager = ServiceManager(tmp_path / "test.db")
    manager.replace_all([sample()])
    assert manager.list_records()[0]["bike_name"] == "Honda Activa"
