# Bike Service Log Pro

A desktop GUI application for tracking motorcycle maintenance records.

## Run on Windows
1. Extract this ZIP.
2. Open the extracted `Bike_Service_Log_Pro` folder in VS Code or File Explorer.
3. Open PowerShell in that folder and run:

```powershell
python main.py
```

Python 3.10+ with Tkinter is recommended. No pip installs are needed.

## Features
- Tkinter desktop dashboard with summary cards
- Add, edit, and delete service records
- Validation for required fields, dates, and odometer readings
- Local JSON and CSV persistence
- Search across bike, category, date, and notes
- Date-based and odometer-based service warnings
- CSV import with invalid-row skipping and CSV export
- Markdown report export
- 35 realistic sample records

## Data files
The app stores records in `data/services.json` and `data/services.csv`.

## Demo flow
1. Launch the app.
2. Add a new service record.
3. Try an invalid date or odometer to show validation.
4. Search for a bike or service category.
5. Update the current odometer and show an odometer alert.
6. Export CSV and Markdown reports.
