import tempfile
import unittest
from pathlib import Path
from finance_reporter.models import Transaction
from finance_reporter.analytics import summarize, search_transactions
from finance_reporter.storage import Storage

def sample():
    return [
        Transaction("a1", "2026-01-01", "Salary", "Work", "income", 30000),
        Transaction("a2", "2026-01-02", "Groceries", "Food", "expense", 2500),
        Transaction("a3", "2026-02-01", "Freelance", "Work", "income", 5000),
    ]

class ReporterTests(unittest.TestCase):
    def test_summary_totals(self):
        result = summarize(sample())
        self.assertEqual(result["total_income"], 35000)
        self.assertEqual(result["total_expenses"], 2500)
        self.assertEqual(result["net_balance"], 32500)

    def test_search(self):
        self.assertEqual(len(search_transactions(sample(), keyword="groc")), 1)
        self.assertEqual(len(search_transactions(sample(), category="Work")), 2)

    def test_validation_rejects_negative_amount(self):
        item = Transaction("x", "2026-01-01", "Test", "Other", "expense", -1)
        with self.assertRaises(ValueError):
            item.validate()

    def test_json_and_csv_persistence(self):
        with tempfile.TemporaryDirectory() as folder:
            storage = Storage(Path(folder))
            storage.save(sample())
            self.assertEqual(len(storage.load()), 3)
            self.assertTrue(storage.csv_path.exists())

if __name__ == "__main__":
    unittest.main()
