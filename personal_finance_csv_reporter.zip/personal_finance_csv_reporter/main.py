"""Personal Finance CSV Reporter - interactive terminal application."""
from finance_reporter.cli import main

if __name__ == "__main__":
    main()
