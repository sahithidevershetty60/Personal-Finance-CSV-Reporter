"""Personal Finance CSV Reporter package."""
__version__ = "1.0.0"
