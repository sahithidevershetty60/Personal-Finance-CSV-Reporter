from dataclasses import dataclass, asdict
from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Any

VALID_TYPES = {"income", "expense"}

@dataclass
class Transaction:
    transaction_id: str
    date: str
    description: str
    category: str
    transaction_type: str
    amount: float
    notes: str = ""

    def validate(self) -> None:
        try:
            date.fromisoformat(self.date)
        except (TypeError, ValueError):
            raise ValueError("Date must use YYYY-MM-DD format.")
        if not self.description.strip():
            raise ValueError("Description cannot be blank.")
        if not self.category.strip():
            raise ValueError("Category cannot be blank.")
        if self.transaction_type.lower() not in VALID_TYPES:
            raise ValueError("Type must be either income or expense.")
        try:
            value = Decimal(str(self.amount))
        except (InvalidOperation, TypeError):
            raise ValueError("Amount must be a valid number.")
        if not value.is_finite() or value <= 0 or value > Decimal("1000000000"):
            raise ValueError("Amount must be greater than 0 and at most 1,000,000,000.")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, row: dict[str, Any]) -> "Transaction":
        return cls(
            transaction_id=str(row["transaction_id"]),
            date=str(row["date"]),
            description=str(row["description"]).strip(),
            category=str(row["category"]).strip(),
            transaction_type=str(row["transaction_type"]).strip().lower(),
            amount=float(row["amount"]),
            notes=str(row.get("notes", "")),
        )
