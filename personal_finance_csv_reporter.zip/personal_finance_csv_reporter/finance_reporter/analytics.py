from collections import defaultdict
from datetime import date
from statistics import mean
from .models import Transaction

def summarize(transactions: list[Transaction]) -> dict:
    incomes = [t.amount for t in transactions if t.transaction_type == "income"]
    expenses = [t.amount for t in transactions if t.transaction_type == "expense"]
    by_category = defaultdict(float)
    by_month = defaultdict(lambda: {"income": 0.0, "expense": 0.0})
    for item in transactions:
        by_category[item.category] += item.amount if item.transaction_type == "expense" else 0
        month = item.date[:7]
        by_month[month][item.transaction_type] += item.amount
    total_income, total_expense = sum(incomes), sum(expenses)
    return {
        "transaction_count": len(transactions),
        "total_income": round(total_income, 2),
        "total_expenses": round(total_expense, 2),
        "net_balance": round(total_income - total_expense, 2),
        "average_income": round(mean(incomes), 2) if incomes else 0.0,
        "average_expense": round(mean(expenses), 2) if expenses else 0.0,
        "savings_rate": round((total_income-total_expense)/total_income*100, 2) if total_income else 0.0,
        "expenses_by_category": dict(sorted(by_category.items(), key=lambda x: x[1], reverse=True)),
        "monthly": dict(sorted(by_month.items())),
    }

def search_transactions(transactions, keyword="", category=""):
    keyword, category = keyword.casefold().strip(), category.casefold().strip()
    return [t for t in transactions
            if (not keyword or keyword in t.description.casefold()
                or keyword in t.notes.casefold() or keyword in t.category.casefold())
            and (not category or category == t.category.casefold())]

def warnings(transactions, expense_limit=10000):
    messages = []
    for item in transactions:
        if item.transaction_type == "expense" and item.amount >= expense_limit:
            messages.append(f"Large expense: {item.description} ({item.amount:.2f}) on {item.date}")
    seen = set()
    for item in transactions:
        if item.transaction_id in seen:
            messages.append(f"Duplicate transaction ID: {item.transaction_id}")
        seen.add(item.transaction_id)
    return messages
