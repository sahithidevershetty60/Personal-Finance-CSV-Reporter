import csv
import json
from pathlib import Path
from .models import Transaction

FIELDS = ["transaction_id", "date", "description", "category",
          "transaction_type", "amount", "notes"]

class Storage:
    """Handles local JSON/CSV persistence without requiring a network."""
    def __init__(self, data_dir: Path):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.json_path = self.data_dir / "transactions.json"
        self.csv_path = self.data_dir / "transactions.csv"

    def load(self) -> list[Transaction]:
        if not self.json_path.exists():
            if self.csv_path.exists():
                return self.import_csv(self.csv_path)[0]
            self.save([])
            return []
        try:
            raw = json.loads(self.json_path.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                raise ValueError("The JSON file must contain a list of transactions.")
            records = []
            for item in raw:
                transaction = Transaction.from_dict(item)
                transaction.validate()
                records.append(transaction)
            return records
        except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            backup = self.json_path.with_suffix(".corrupt.json")
            try:
                self.json_path.replace(backup)
            except OSError:
                pass
            print(f"Warning: storage file was invalid ({exc}). A fresh file will be created.")
            self.save([])
            return []

    def save(self, transactions: list[Transaction]) -> None:
        payload = [item.to_dict() for item in transactions]
        temp = self.json_path.with_suffix(".tmp")
        temp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        temp.replace(self.json_path)
        self.export_csv(transactions, self.csv_path)

    @staticmethod
    def export_csv(transactions: list[Transaction], path: Path) -> None:
        with Path(path).open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(item.to_dict() for item in transactions)

    @staticmethod
    def import_csv(path: Path) -> tuple[list[Transaction], list[str]]:
        accepted, errors = [], []
        with Path(path).open("r", newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            missing = set(FIELDS[:-1]) - set(reader.fieldnames or [])
            if missing:
                return [], [f"Missing required column(s): {', '.join(sorted(missing))}"]
            for line_number, row in enumerate(reader, start=2):
                try:
                    item = Transaction.from_dict(row)
                    item.validate()
                    accepted.append(item)
                except (ValueError, TypeError, KeyError) as exc:
                    errors.append(f"Row {line_number}: {exc}")
        return accepted, errors
