from pathlib import Path
from uuid import uuid4
from datetime import date
from .models import Transaction
from .storage import Storage
from .analytics import summarize, search_transactions, warnings
from .reports import export_summary, create_charts

BASE_DIR = Path(__file__).resolve().parent.parent

def ask_text(prompt):
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("Please enter a value; it cannot be blank.")

def ask_amount(prompt="Amount: "):
    while True:
        raw = input(prompt).strip().replace(",", "")
        try:
            amount = float(raw)
            if 0 < amount <= 1_000_000_000:
                return round(amount, 2)
        except ValueError:
            pass
        print("Enter a number greater than 0 and no more than 1,000,000,000.")

def add_transaction(records, storage):
    raw_date = input(f"Date [YYYY-MM-DD, default {date.today().isoformat()}]: ").strip()
    raw_date = raw_date or date.today().isoformat()
    try:
        date.fromisoformat(raw_date)
    except ValueError:
        print("Invalid date. Use YYYY-MM-DD."); return
    kind = input("Type (income/expense): ").strip().lower()
    if kind not in {"income", "expense"}:
        print("Type must be income or expense."); return
    item = Transaction(str(uuid4())[:8], raw_date, ask_text("Description: "),
                       ask_text("Category: "), kind, ask_amount(), input("Notes (optional): ").strip())
    item.validate()
    records.append(item); storage.save(records)
    print("Transaction saved.")

def print_records(records):
    if not records:
        print("No transactions found."); return
    print("-" * 92)
    print(f"{'DATE':<12} {'TYPE':<9} {'CATEGORY':<16} {'DESCRIPTION':<27} {'AMOUNT':>12}")
    print("-" * 92)
    for item in records:
        print(f"{item.date:<12} {item.transaction_type:<9} {item.category[:15]:<16} "
              f"{item.description[:26]:<27} {item.amount:>12.2f}")
    print("-" * 92)

def show_summary(records):
    s = summarize(records)
    print("\\n=== FINANCIAL SUMMARY ===")
    print(f"Transactions : {s['transaction_count']}")
    print(f"Income       : {s['total_income']:,.2f}")
    print(f"Expenses     : {s['total_expenses']:,.2f}")
    print(f"Net balance  : {s['net_balance']:,.2f}")
    print(f"Savings rate : {s['savings_rate']:.2f}%")
    print("\\nExpenses by category:")
    for category, amount in s["expenses_by_category"].items():
        print(f"  {category:<20} {amount:>12,.2f}")
    for message in warnings(records):
        print(f"WARNING: {message}")

def main():
    storage = Storage(BASE_DIR / "data")
    records = storage.load()
    print("\\n" + "=" * 54)
    print("       PERSONAL FINANCE CSV REPORTER")
    print("       Simple, local and private money tracking")
    print("=" * 54)
    while True:
        print("""
1. Add a transaction
2. View all transactions
3. Import transactions from CSV
4. Search / filter transactions
5. View executive summary
6. Export reports (Markdown, TXT, CSV)
7. Generate charts
8. Exit
""")
        choice = input("Choose an option (1-8): ").strip()
        if choice == "1":
            add_transaction(records, storage)
        elif choice == "2":
            print_records(records)
        elif choice == "3":
            path = Path(ask_text("CSV file path: ")).expanduser()
            try:
                imported, errors = Storage.import_csv(path)
                existing = {t.transaction_id for t in records}
                added = [t for t in imported if t.transaction_id not in existing]
                records.extend(added); storage.save(records)
                print(f"Imported {len(added)} transaction(s).")
                for error in errors:
                    print(error)
            except OSError as exc:
                print(f"Could not read CSV: {exc}")
        elif choice == "4":
            keyword = input("Keyword (optional): ")
            category = input("Exact category (optional): ")
            print_records(search_transactions(records, keyword, category))
        elif choice == "5":
            show_summary(records)
        elif choice == "6":
            export_summary(records, BASE_DIR / "reports")
            print("Reports saved in the reports folder.")
        elif choice == "7":
            print(create_charts(records, BASE_DIR / "reports"))
        elif choice == "8":
            print("Your data is saved locally. Goodbye!")
            break
        else:
            print("Choose a number from 1 to 8.")

if __name__ == "__main__":
    main()
