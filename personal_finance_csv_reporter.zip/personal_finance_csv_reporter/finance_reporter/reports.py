from pathlib import Path
from .analytics import summarize
from .storage import Storage

def export_summary(transactions, output_dir: Path):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    summary = summarize(transactions)
    lines = [
        "# Personal Finance Summary", "",
        f"- Transactions: {summary['transaction_count']}",
        f"- Total income: {summary['total_income']:.2f}",
        f"- Total expenses: {summary['total_expenses']:.2f}",
        f"- Net balance: {summary['net_balance']:.2f}",
        f"- Savings rate: {summary['savings_rate']:.2f}%", "",
        "## Expenses by category"
    ]
    lines += [f"- {name}: {amount:.2f}" for name, amount in summary["expenses_by_category"].items()]
    (output_dir / "summary.md").write_text("\\n".join(lines), encoding="utf-8")
    (output_dir / "summary.txt").write_text("\\n".join(lines).replace("#", ""), encoding="utf-8")
    Storage.export_csv(transactions, output_dir / "transactions_export.csv")
    return summary

def create_charts(transactions, output_dir: Path):
    """Create PNG charts. Matplotlib is optional; return a friendly message if absent."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return "Matplotlib is not installed. Run: pip install matplotlib"
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    summary = summarize(transactions)
    if summary["monthly"]:
        months = list(summary["monthly"])
        plt.figure(figsize=(9, 5))
        plt.plot(months, [summary["monthly"][m]["income"] for m in months], marker="o", label="Income")
        plt.plot(months, [summary["monthly"][m]["expense"] for m in months], marker="o", label="Expenses")
        plt.title("Monthly income and expenses")
        plt.xlabel("Month"); plt.ylabel("Amount"); plt.xticks(rotation=35); plt.legend()
        plt.tight_layout(); plt.savefig(output_dir / "monthly_trend.png"); plt.close()
    if summary["expenses_by_category"]:
        plt.figure(figsize=(8, 5))
        labels = list(summary["expenses_by_category"])
        values = list(summary["expenses_by_category"].values())
        plt.bar(labels, values)
        plt.title("Expenses by category"); plt.ylabel("Amount")
        plt.xticks(rotation=30, ha="right")
        plt.tight_layout(); plt.savefig(output_dir / "category_distribution.png"); plt.close()
    return "Charts saved in the reports folder."
