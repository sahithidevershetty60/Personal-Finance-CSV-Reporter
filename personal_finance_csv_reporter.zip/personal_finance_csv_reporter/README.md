# Personal Finance CSV Reporter

A beginner-friendly, menu-driven Python application for importing, validating, searching and analysing personal finance transactions. It works locally; it does not upload financial data to a server.

## Features

- Interactive terminal menu with input checks.
- Add income and expense transactions.
- Import bulk CSV data with row-by-row error messages.
- Store records in JSON and keep a matching CSV copy.
- Search by keyword and filter by category.
- Calculate income, expenses, net balance, averages, savings rate and monthly totals.
- Flag unusually large expenses and duplicate transaction IDs.
- Export Markdown, text and CSV reports.
- Generate monthly trend and category charts with Matplotlib.
- Unit tests for core calculations, validation, search and persistence.

## Requirements

- Python 3.10 or newer.
- Matplotlib is optional for charts; all other features use the Python standard library.

## Run on Windows

```powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python main.py
```

If you do not need charts, you can run `python main.py` without installing Matplotlib.

## Run on macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python main.py
```

## CSV format

The importer expects these column headers:

`transaction_id,date,description,category,transaction_type,amount,notes`

- Date format: `YYYY-MM-DD`
- Type: `income` or `expense`
- Amount: positive number, maximum 1,000,000,000
- `notes` may be blank.

A ready-to-use 40-row example is available at `data/sample_transactions.csv`. To import it, choose menu option 3 and enter that file path.

## Data and generated files

- `data/transactions.json` — main persistent data file, created automatically.
- `data/transactions.csv` — matching CSV copy.
- `reports/summary.md`, `reports/summary.txt`, `reports/transactions_export.csv` — exported reports.
- `reports/*.png` — charts.

Keep real financial data private. The sample data is fictional. Back up your `data` folder if you need to preserve your records.

## Run tests

```bash
python -m unittest discover -s tests -v
```

## Project structure

```text
personal-finance-csv-reporter/
├── finance_reporter/
│   ├── __init__.py
│   ├── analytics.py
│   ├── cli.py
│   ├── models.py
│   ├── reports.py
│   └── storage.py
├── data/
│   └── sample_transactions.csv
├── reports/
├── tests/
│   └── test_reporter.py
├── main.py
├── requirements.txt
├── .gitignore
└── README.md
```

## GitHub upload

1. Create a new empty repository on GitHub. A suitable name is `personal-finance-csv-reporter`.
2. Open this project folder in VS Code.
3. Open Terminal → New Terminal.
4. Run the commands below from the project folder (replace the URL with your repository URL):

```bash
git init
git add .
git commit -m "Build Personal Finance CSV Reporter"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/personal-finance-csv-reporter.git
git push -u origin main
```

5. Refresh the GitHub repository page. Your files should appear.
6. For later changes, run:

```bash
git add .
git commit -m "Describe your update"
git push
```

If Git asks you to authenticate, complete the browser sign-in prompt or use GitHub's supported credential manager. Do not put passwords or tokens inside project files.

## Demo flow

1. Start the program and show the menu.
2. Import `data/sample_transactions.csv`.
3. View all transactions.
4. Search for `grocery` or filter by `Food`.
5. Show the executive summary and warning messages.
6. Export reports and generate charts.
7. Exit and relaunch to demonstrate that the data remains saved.

## Notes

This is an educational project, not a bank-connected financial adviser. It analyses only the records supplied by the user. The large-expense warning uses a simple default threshold of 10,000 and is intended as a prompt for review, not a fraud detector.
