# Pushing this project to GitHub

## One-time setup
1. Install Git: https://git-scm.com/downloads
2. Make a free account at https://github.com
3. Tell Git who you are (use the email on your GitHub account):
   ```bash
   git config --global user.name "Your Name"
   git config --global user.email "you@example.com"
   ```

## Create the empty repository on GitHub
1. Click the **+** at the top right, then **New repository**
2. Name it `personal-finance-csv-reporter`
3. Choose Public (or Private)
4. Leave **Add a README**, **.gitignore** and **license** UNCHECKED, because the project already has them
5. Click **Create repository** and keep the page open

## Push your code
Unzip the project, open a terminal inside the folder, then run:

```bash
git init
git add .
git commit -m "Initial commit: Personal Finance CSV Reporter"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/personal-finance-csv-reporter.git
git push -u origin main
```

When Git asks for a password, use a Personal Access Token, not your account password:
GitHub, then Settings, Developer settings, Personal access tokens, Tokens (classic),
Generate new token, tick `repo`, and paste it as the password.
(Or install GitHub CLI and run `gh auth login` first.)

## Later changes
```bash
git add .
git commit -m "Describe what you changed"
git push
```

## Before you submit
- Replace `YOUR NAME` in LICENSE and `YOUR-USERNAME` in README.md
- Run the tests once and take a screenshot or short recording of the demo
- Check `git status` shows nothing unexpected, and that `data/transactions.json` is not in the repo
