# Personal Finance CSV Reporter

A terminal app that loads transactions from CSV, checks every entry, and turns
them into summaries, warnings, charts and exportable reports. Built for the
LocalImpact hackathon (Project #20). Only the standard library is needed, plus
matplotlib for charts.

## Features

- Menu-driven terminal interface (colour output, pagination for long lists)
- Strict validation for dates, amounts, types and categories. Bad input is
  explained and re-asked, never a crash
- Bulk CSV import with a row-by-row error log (`reports/import_errors.log`)
  and duplicate detection
- JSON persistence. Missing or corrupted files are handled on launch, and
  saves are written atomically
- Search by keyword, category, type and date range
- Summary: totals, savings rate, averages, category shares, monthly table, trend line
- Warnings: months over income, budget breaches, dominant categories, unusually large expenses
- Charts (PNG): income vs expenses per month, spending by category, running balance
- Export to Markdown, plain-text audit log and CSV

## Setup

```bash
git clone https://github.com/YOUR-USERNAME/personal-finance-csv-reporter.git
cd personal-finance-csv-reporter

python -m venv venv
# Windows:  venv\Scripts\activate
# Mac/Linux: source venv/bin/activate

pip install -r requirements.txt
python main.py
```

Requires Python 3.10 or newer.

## Quick demo

1. Start the app and choose **10** to load the 49-row sample dataset
2. Choose **1** and try a bad date (`2026-02-30`) or amount (`-50`) to see validation
3. Choose **5** for the summary and warnings
4. Choose **4** and import `data/messy_import_demo.csv` to see rejected rows explained
5. Choose **6** and **7** to create charts and reports in `reports/`
6. Quit (**0**), start the app again, and everything is still there

## CSV format

```csv
date,type,category,description,amount
2026-01-01,income,Salary,January salary,65000
2026-01-03,expense,Rent,Flat rent,18000
```

- `date`: `YYYY-MM-DD` or `DD/MM/YYYY`, not in the future
- `type`: `income` or `expense` (also `credit`/`debit`)
- `amount`: more than 0 and up to 10,000,000. Commas and ₹/$ signs are fine
- `description` is optional

## Project layout

```
main.py                  menu and program loop
finance/
  validation.py          parsing, range checks, input loops
  models.py              Transaction dataclass
  storage.py             JSON load/save, corruption handling
  importer.py            CSV import and error log
  analytics.py           totals, trends, warnings, search
  charts.py              matplotlib charts
  exporter.py            Markdown / text / CSV reports
  ui.py                  colours, tables, pagination
data/                    sample CSV, sample JSON, messy demo CSV
tests/                   unit tests
```

## Tests

```bash
python -m unittest discover -s tests -t .
```

## How the warnings work

- A month is flagged when spending is higher than income, or higher than the budget you set
- A category is flagged when it takes 40% or more of all spending
- Expenses in categories with 4+ entries are flagged when they sit 2 standard
  deviations above that category's average. In smaller categories, an expense
  is flagged when it is 10x the overall median

## License

MIT
