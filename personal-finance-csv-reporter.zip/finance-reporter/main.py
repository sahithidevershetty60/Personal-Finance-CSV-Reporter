"""Personal Finance CSV Reporter - menu-driven entry point.

Run with:  python main.py
"""
import sys
from pathlib import Path

from finance import analytics, charts, exporter, importer, ui
from finance.storage import Store
from finance.validation import (EXPENSE, INCOME, CancelInput, ask, ask_optional,
                                parse_amount, parse_category, parse_date,
                                parse_description, parse_positive_int, parse_type)

ROOT = Path(__file__).resolve().parent
REPORT_DIR = ROOT / "reports"
SAMPLE_CSV = ROOT / "data" / "sample_transactions.csv"
ERROR_LOG = ROOT / "reports" / "import_errors.log"

MENU = """
 1) Add a transaction
 2) View all transactions
 3) Search / filter
 4) Import from CSV
 5) Summary report
 6) Charts (saved as PNG)
 7) Export report (Markdown, text, CSV)
 8) Set monthly budget
 9) Delete a transaction
10) Load the sample dataset
 0) Quit
 (type 'cancel' at any prompt to go back)
"""


def pause():
    input("\nPress Enter to continue...")


def add_transaction(store):
    print(ui.bold("\nNew transaction"))
    tx_type = ask("Type (income/expense)", parse_type)
    when = ask("Date (YYYY-MM-DD or DD/MM/YYYY)", parse_date)
    category = ask("Category", parse_category)
    description = ask("Description (optional)", parse_description, default="")
    amount = ask("Amount", parse_amount)
    tx = store.add(when, tx_type, category, description, amount)
    print(ui.green(f"  Saved as #{tx.id}."))


def view_all(store):
    ordered = sorted(store.transactions, key=lambda t: (t.date, t.id))
    print()
    ui.print_transactions(ordered)


def search_menu(store):
    print(ui.bold("\nSearch (press Enter to skip any filter)"))
    keyword = ask_optional("Keyword in description/category", lambda s: s.strip())
    category = ask_optional("Exact category", parse_category)
    tx_type = ask_optional("Type (income/expense)", parse_type)
    start = ask_optional("From date", parse_date)
    end = ask_optional("To date", parse_date)
    if start and end and start > end:
        print(ui.yellow("  'From' was after 'To', so I swapped them."))
        start, end = end, start
    results = analytics.search(store.transactions, keyword, category, tx_type, start, end)
    print()
    ui.print_transactions(results)
    if results:
        total_in = sum(t.amount for t in results if t.type == INCOME)
        total_out = sum(t.amount for t in results if t.type == EXPENSE)
        print(f"  Matches: income {ui.money(total_in)}, expenses {ui.money(total_out)}")


def import_menu(store):
    path = ask("Path to CSV file", lambda s: s.strip().strip('"').strip("'") or _fail("Path cannot be blank."))
    result = importer.import_csv(path, store.transactions)
    if result.fatal:
        print(ui.red("  " + result.fatal))
        return
    added = store.add_many(result.valid)
    print(ui.green(f"\n  Imported {added} row(s)."))
    if result.duplicates:
        print(f"  Skipped {result.duplicates} duplicate row(s).")
    if result.errors:
        print(ui.yellow(f"  Rejected {len(result.errors)} row(s):"))
        for line, reason in result.errors:
            print(f"    line {line}: {reason}")
        log = importer.write_error_log(result, Path(path).name, ERROR_LOG)
        print(f"  Details saved to {log}")


def _fail(message):
    raise ValueError(message)


def summary_report(store):
    if not store.transactions:
        print(ui.yellow("\n  No data yet. Add transactions or import a CSV first."))
        return
    s = analytics.summarize(store.transactions)
    trend = analytics.describe_trend(s)
    warnings = analytics.build_warnings(store.transactions, store.settings["monthly_budget"])
    ui.print_summary(s, trend, warnings)


def charts_menu(store):
    paths, problem = charts.make_charts(store.transactions, REPORT_DIR)
    if problem:
        print(ui.yellow("  " + problem))
        return
    print(ui.green("\n  Charts saved:"))
    for p in paths:
        print(f"    {p}")


def export_menu(store):
    if not store.transactions:
        print(ui.yellow("\n  Nothing to export yet."))
        return
    budget = store.settings["monthly_budget"]
    print(ui.green("\n  Reports written:"))
    for func in (exporter.export_markdown, exporter.export_text, exporter.export_csv):
        print(f"    {func(store.transactions, REPORT_DIR, budget)}")


def budget_menu(store):
    current = store.settings["monthly_budget"]
    print(f"\n  Current monthly budget: {ui.money(current) if current else 'not set'}")
    store.set_budget(ask("New monthly budget", parse_amount))
    print(ui.green("  Budget saved."))


def delete_menu(store):
    view_all(store)
    tx_id = ask("ID to delete", lambda s: parse_positive_int(s, 1, 10**9))
    match = next((t for t in store.transactions if t.id == tx_id), None)
    if not match:
        print(ui.yellow(f"  No transaction with ID {tx_id}."))
        return
    confirm = input(f"  Delete '{match.description or match.category}' for {ui.money(match.amount)}? (y/n): ")
    if confirm.strip().lower() == "y":
        store.delete(tx_id)
        print(ui.green("  Deleted."))
    else:
        print("  Kept it.")


def load_sample(store):
    if not SAMPLE_CSV.exists():
        print(ui.red("  Sample file is missing."))
        return
    result = importer.import_csv(SAMPLE_CSV, store.transactions)
    added = store.add_many(result.valid)
    print(ui.green(f"  Loaded {added} sample transaction(s)."))
    if result.duplicates:
        print(f"  ({result.duplicates} were already there.)")


ACTIONS = {
    "1": add_transaction, "2": view_all, "3": search_menu, "4": import_menu,
    "5": summary_report, "6": charts_menu, "7": export_menu, "8": budget_menu,
    "9": delete_menu, "10": load_sample,
}


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    store = Store()
    ui.banner()
    for note in store.load_notes:
        print(ui.yellow("  " + note))
    print(f"  {len(store.transactions)} transaction(s) loaded.")

    while True:
        print(MENU)
        try:
            choice = input("Choose an option: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break
        if choice == "0":
            print("Your data is saved. Goodbye.")
            break
        action = ACTIONS.get(choice)
        if not action:
            print(ui.yellow("  Please pick a number from the menu."))
            continue
        try:
            action(store)
        except CancelInput:
            print(ui.dim("  Cancelled."))
        except KeyboardInterrupt:
            print(ui.dim("\n  Cancelled."))
        except OSError as err:
            print(ui.red(f"  File problem: {err}"))
        try:
            pause()
        except (EOFError, KeyboardInterrupt):
            print()
            break


if __name__ == "__main__":
    main()
