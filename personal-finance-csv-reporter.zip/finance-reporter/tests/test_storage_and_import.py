import json
import tempfile
import unittest
from datetime import date
from pathlib import Path

from finance.importer import import_csv
from finance.storage import Store


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "t.json"

    def tearDown(self):
        self.tmp.cleanup()

    def test_missing_file_is_created(self):
        store = Store(self.path)
        self.assertEqual(store.transactions, [])
        self.assertTrue(self.path.exists())

    def test_data_survives_restart(self):
        Store(self.path).add(date(2026, 1, 5), "expense", "Food", "lunch", 120.5)
        again = Store(self.path)
        self.assertEqual(len(again.transactions), 1)
        self.assertEqual(again.transactions[0].amount, 120.5)

    def test_corrupt_file_is_set_aside(self):
        self.path.write_text("{ not json", encoding="utf-8")
        store = Store(self.path)
        self.assertEqual(store.transactions, [])
        self.assertTrue(store.load_notes)
        self.assertTrue(list(Path(self.tmp.name).glob("*.corrupt-*")))

    def test_damaged_records_are_skipped(self):
        good = {"id": 1, "date": "2026-01-01", "type": "income", "category": "Salary",
                "description": "", "amount": 100}
        bad = {"id": 2, "date": "nope", "type": "income", "category": "Salary", "amount": 5}
        self.path.write_text(json.dumps({"transactions": [good, bad]}), encoding="utf-8")
        store = Store(self.path)
        self.assertEqual(len(store.transactions), 1)
        self.assertTrue(store.load_notes)


class ImportTests(unittest.TestCase):
    def test_row_errors_are_reported_with_line_numbers(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "in.csv"
            p.write_text("date,type,category,description,amount\n"
                         "2026-01-01,income,Salary,ok,100\n"
                         "2026-01-02,expense,Food,bad amount,abc\n"
                         "2026-01-01,income,Salary,ok,100\n", encoding="utf-8")
            r = import_csv(p)
            self.assertEqual(len(r.valid), 1)
            self.assertEqual(r.duplicates, 1)
            self.assertEqual([line for line, _ in r.errors], [3])

    def test_missing_columns_and_file(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "in.csv"
            p.write_text("date,amount\n2026-01-01,5\n", encoding="utf-8")
            self.assertIn("Missing", import_csv(p).fatal)
        self.assertIn("not found", import_csv("/no/such/file.csv").fatal)


if __name__ == "__main__":
    unittest.main()
