import unittest
from datetime import date, timedelta

from finance.validation import (parse_amount, parse_category, parse_date,
                                parse_type)


class DateTests(unittest.TestCase):
    def test_accepts_iso_and_indian_format(self):
        self.assertEqual(parse_date("2026-03-14"), date(2026, 3, 14))
        self.assertEqual(parse_date("14/03/2026"), date(2026, 3, 14))

    def test_rejects_garbage_future_and_ancient(self):
        for bad in ("", "tomorrow", "2026-13-40", "1999-12-31"):
            with self.assertRaises(ValueError):
                parse_date(bad)
        with self.assertRaises(ValueError):
            parse_date((date.today() + timedelta(days=2)).isoformat())


class AmountTests(unittest.TestCase):
    def test_valid_amounts(self):
        self.assertEqual(parse_amount("450"), 450.0)
        self.assertEqual(parse_amount("₹1,299.50"), 1299.5)
        self.assertEqual(parse_amount("0.01"), 0.01)
        self.assertEqual(parse_amount("10.456"), 10.46)

    def test_invalid_amounts(self):
        for bad in ("", "abc", "-5", "0", "nan", "inf", "0.001", "99999999"):
            with self.assertRaises(ValueError, msg=bad):
                parse_amount(bad)


class OtherFieldTests(unittest.TestCase):
    def test_type_aliases(self):
        self.assertEqual(parse_type("Debit"), "expense")
        self.assertEqual(parse_type(" IN "), "income")
        with self.assertRaises(ValueError):
            parse_type("transfer")

    def test_category_cleanup(self):
        self.assertEqual(parse_category("  eating   out "), "Eating Out")
        for bad in ("", "x" * 31, "rm -rf;"):
            with self.assertRaises(ValueError):
                parse_category(bad)


if __name__ == "__main__":
    unittest.main()
