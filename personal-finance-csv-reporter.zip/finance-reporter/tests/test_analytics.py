import unittest
from datetime import date

from finance.analytics import (build_warnings, describe_trend, find_anomalies,
                               search, summarize)
from finance.models import Transaction


def tx(i, d, kind, cat, amount, desc=""):
    return Transaction(i, d, kind, cat, desc, amount)


class AnalyticsTests(unittest.TestCase):
    def setUp(self):
        self.data = [
            tx(1, date(2026, 1, 1), "income", "Salary", 1000),
            tx(2, date(2026, 1, 5), "expense", "Food", 200, "Groceries"),
            tx(3, date(2026, 2, 1), "income", "Salary", 1000),
            tx(4, date(2026, 2, 5), "expense", "Food", 300, "Dinner"),
        ]

    def test_totals(self):
        s = summarize(self.data)
        self.assertEqual(s["total_income"], 2000)
        self.assertEqual(s["total_expense"], 500)
        self.assertEqual(s["net"], 1500)
        self.assertEqual(s["savings_rate"], 75.0)
        self.assertEqual(s["avg_expense"], 250)

    def test_empty_data_does_not_crash(self):
        s = summarize([])
        self.assertEqual(s["net"], 0)
        self.assertIsNone(s["savings_rate"])
        self.assertEqual(build_warnings([]), [])

    def test_trend_text(self):
        self.assertIn("up 50.0%", describe_trend(summarize(self.data)))

    def test_search_filters(self):
        self.assertEqual([t.id for t in search(self.data, keyword="dinner")], [4])
        self.assertEqual(len(search(self.data, tx_type="income")), 2)
        self.assertEqual(len(search(self.data, start=date(2026, 2, 1))), 2)

    def test_anomaly_detection(self):
        rows = [tx(i, date(2026, 1, i), "expense", "Food", 100) for i in range(1, 8)]
        rows.append(tx(99, date(2026, 1, 20), "expense", "Food", 1000))
        flagged = find_anomalies(rows)
        self.assertEqual([t.id for t, _, _ in flagged], [99])

    def test_budget_warning(self):
        warns = build_warnings(self.data, monthly_budget=250)
        self.assertTrue(any("over the monthly budget" in w for w in warns))


if __name__ == "__main__":
    unittest.main()


class SmallCategoryAnomalyTest(unittest.TestCase):
    def test_one_off_big_purchase_is_flagged(self):
        rows = [tx(i, date(2026, 1, i), "expense", "Food", 100) for i in range(1, 7)]
        rows.append(tx(50, date(2026, 1, 25), "expense", "Shopping", 5000, "Laptop"))
        self.assertEqual([t.id for t, _, _ in find_anomalies(rows)], [50])
