"""The Transaction record."""
from dataclasses import dataclass
from datetime import date

from .validation import (parse_amount, parse_category, parse_date,
                         parse_description, parse_type)


@dataclass
class Transaction:
    id: int
    date: date
    type: str
    category: str
    description: str
    amount: float

    def to_dict(self):
        return {
            "id": self.id,
            "date": self.date.isoformat(),
            "type": self.type,
            "category": self.category,
            "description": self.description,
            "amount": self.amount,
        }

    @classmethod
    def from_dict(cls, data):
        """Rebuild a record from stored data, re-checking every field.

        Raises ValueError / KeyError / TypeError if the record is damaged.
        """
        return cls(
            id=int(data["id"]),
            date=parse_date(str(data["date"])),
            type=parse_type(str(data["type"])),
            category=parse_category(str(data["category"])),
            description=parse_description(str(data.get("description", ""))),
            amount=parse_amount(str(data["amount"])),
        )
