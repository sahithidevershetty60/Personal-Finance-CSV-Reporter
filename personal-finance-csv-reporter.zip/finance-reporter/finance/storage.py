"""Saving and loading data as JSON.

If the file is missing we start clean. If it is corrupted we move it aside
as *.corrupt-<timestamp> and start clean, so the program never crashes on launch.
"""
import json
import os
import tempfile
import time
from pathlib import Path

from .models import Transaction

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
DEFAULT_FILE = DATA_DIR / "transactions.json"


class Store:
    def __init__(self, path=DEFAULT_FILE):
        self.path = Path(path)
        self.transactions = []
        self.settings = {"monthly_budget": None}
        self.load_notes = []   # messages to show the user after loading
        self.load()

    # ---- loading -------------------------------------------------------
    def load(self):
        self.transactions = []
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict) or not isinstance(raw.get("transactions"), list):
                raise ValueError("unexpected file layout")
        except FileNotFoundError:
            self.save()
            return
        except (json.JSONDecodeError, ValueError, UnicodeDecodeError, OSError):
            self._quarantine()
            return

        skipped = 0
        for item in raw["transactions"]:
            try:
                self.transactions.append(Transaction.from_dict(item))
            except (ValueError, KeyError, TypeError):
                skipped += 1
        if skipped:
            self.load_notes.append(f"Skipped {skipped} damaged record(s) while loading.")

        settings = raw.get("settings")
        if isinstance(settings, dict):
            budget = settings.get("monthly_budget")
            if isinstance(budget, (int, float)) and not isinstance(budget, bool) and budget > 0:
                self.settings["monthly_budget"] = float(budget)

    def _quarantine(self):
        backup = self.path.with_suffix(f".corrupt-{int(time.time())}")
        try:
            os.replace(self.path, backup)
            self.load_notes.append(
                f"Data file was unreadable. Saved a copy as {backup.name} and started fresh.")
        except OSError:
            self.load_notes.append("Data file was unreadable. Started fresh.")
        self.save()

    # ---- saving --------------------------------------------------------
    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": 1,
            "settings": self.settings,
            "transactions": [t.to_dict() for t in self.transactions],
        }
        # write to a temp file first so a crash mid-write can't wipe the data
        fd, tmp_name = tempfile.mkstemp(dir=self.path.parent, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2, ensure_ascii=False)
            os.replace(tmp_name, self.path)
        except OSError:
            if os.path.exists(tmp_name):
                os.remove(tmp_name)
            raise

    # ---- changes -------------------------------------------------------
    def next_id(self):
        return max((t.id for t in self.transactions), default=0) + 1

    def add(self, date, type_, category, description, amount):
        tx = Transaction(self.next_id(), date, type_, category, description, amount)
        self.transactions.append(tx)
        self.save()
        return tx

    def add_many(self, rows):
        """rows: validated dicts with date, type, category, description, amount."""
        for row in rows:
            self.transactions.append(Transaction(
                self.next_id(), row["date"], row["type"], row["category"],
                row["description"], row["amount"]))
        if rows:
            self.save()
        return len(rows)

    def delete(self, tx_id):
        before = len(self.transactions)
        self.transactions = [t for t in self.transactions if t.id != tx_id]
        removed = len(self.transactions) < before
        if removed:
            self.save()
        return removed

    def set_budget(self, amount):
        self.settings["monthly_budget"] = amount
        self.save()
