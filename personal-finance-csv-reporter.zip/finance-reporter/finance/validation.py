"""Input parsing and validation.

The parse_* functions are pure (string in, value out, ValueError on bad
input) so they are easy to test. The ask* functions wrap them in a loop
so the terminal never crashes on bad input.
"""
import re
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

INCOME = "income"
EXPENSE = "expense"

MIN_DATE = date(2000, 1, 1)
MAX_AMOUNT = 10_000_000.00
MAX_TEXT = 60

DATE_FORMATS = ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y")

TYPE_ALIASES = {
    "income": INCOME, "in": INCOME, "credit": INCOME, "i": INCOME, "1": INCOME,
    "expense": EXPENSE, "out": EXPENSE, "debit": EXPENSE, "e": EXPENSE, "2": EXPENSE,
}


class CancelInput(Exception):
    """Raised when the user types 'cancel' at a prompt."""


def parse_date(text):
    text = (text or "").strip()
    for fmt in DATE_FORMATS:
        try:
            parsed = datetime.strptime(text, fmt).date()
        except ValueError:
            continue
        if parsed < MIN_DATE:
            raise ValueError(f"Date is before {MIN_DATE.isoformat()}.")
        if parsed > date.today():
            raise ValueError("Date is in the future.")
        return parsed
    raise ValueError("Use YYYY-MM-DD or DD/MM/YYYY (e.g. 2026-03-14).")


def parse_amount(text):
    cleaned = re.sub(r"[₹$,\s]|rs\.?|inr", "", (text or "").strip(), flags=re.IGNORECASE)
    if not cleaned:
        raise ValueError("Amount cannot be blank.")
    try:
        value = Decimal(cleaned)
    except InvalidOperation:
        raise ValueError("Amount must be a number, like 450 or 1299.50.")
    if not value.is_finite():
        raise ValueError("Amount must be a real number.")
    if value <= 0:
        raise ValueError("Amount must be greater than zero.")
    value = round(float(value), 2)
    if value <= 0:
        raise ValueError("Amount is too small (minimum 0.01).")
    if value > MAX_AMOUNT:
        raise ValueError(f"Amount is above the limit of {MAX_AMOUNT:,.0f}.")
    return value


def parse_type(text):
    key = (text or "").strip().lower()
    if key not in TYPE_ALIASES:
        raise ValueError("Type must be 'income' or 'expense'.")
    return TYPE_ALIASES[key]


def parse_category(text):
    cleaned = " ".join((text or "").split())
    if not cleaned:
        raise ValueError("Category cannot be blank.")
    if len(cleaned) > 30:
        raise ValueError("Category must be 30 characters or fewer.")
    if not re.fullmatch(r"[A-Za-z0-9 &/\-]+", cleaned):
        raise ValueError("Category can only contain letters, numbers, spaces, & / -")
    return cleaned.title()


def parse_description(text):
    cleaned = " ".join((text or "").split())
    if len(cleaned) > MAX_TEXT:
        raise ValueError(f"Description must be {MAX_TEXT} characters or fewer.")
    return cleaned


def parse_positive_int(text, low=1, high=1000):
    try:
        value = int((text or "").strip())
    except ValueError:
        raise ValueError("Enter a whole number.")
    if not low <= value <= high:
        raise ValueError(f"Enter a number between {low} and {high}.")
    return value


def ask(label, parser, default=None):
    """Keep asking until parser accepts the input. Typing 'cancel' backs out."""
    while True:
        suffix = f" [{default}]" if default not in (None, "") else ""
        raw = input(f"{label}{suffix}: ").strip()
        if raw.lower() == "cancel":
            raise CancelInput()
        if raw == "" and default is not None:
            raw = str(default)
        try:
            return parser(raw)
        except ValueError as err:
            print(f"  x {err}")


def ask_optional(label, parser):
    """Blank input means 'skip' and returns None."""
    while True:
        raw = input(f"{label} (Enter to skip): ").strip()
        if raw.lower() == "cancel":
            raise CancelInput()
        if raw == "":
            return None
        try:
            return parser(raw)
        except ValueError as err:
            print(f"  x {err}")
