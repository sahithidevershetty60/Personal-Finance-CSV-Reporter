"""Matplotlib charts. If matplotlib is missing we say so instead of crashing."""
from datetime import datetime
from pathlib import Path

from .analytics import summarize
from .validation import EXPENSE


def _load_pyplot():
    try:
        import matplotlib
        matplotlib.use("Agg")   # draw to files, no window needed
        import matplotlib.pyplot as plt
        return plt
    except ImportError:
        return None


def make_charts(transactions, out_dir, show=False):
    """Create three PNG charts. Returns (list_of_paths, error_message_or_None)."""
    plt = _load_pyplot()
    if plt is None:
        return [], "matplotlib is not installed. Run: pip install matplotlib"
    if not transactions:
        return [], "No transactions to plot yet."

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    s = summarize(transactions)
    paths = []

    # 1. income vs expense by month
    months = s["months"]
    x = range(len(months))
    inc = [s["monthly"][m]["income"] for m in months]
    exp = [s["monthly"][m]["expense"] for m in months]
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.bar([i - 0.2 for i in x], inc, width=0.4, label="Income", color="#2e8b57")
    ax.bar([i + 0.2 for i in x], exp, width=0.4, label="Expenses", color="#c0392b")
    ax.set_xticks(list(x))
    ax.set_xticklabels(months, rotation=45, ha="right")
    ax.set_title("Income vs expenses by month")
    ax.set_ylabel("Amount")
    ax.legend()
    fig.tight_layout()
    p = out_dir / f"monthly_{stamp}.png"
    fig.savefig(p, dpi=120)
    paths.append(p)
    plt.close(fig)

    # 2. where the money goes
    if s["categories"]:
        top = s["categories"][:7]
        rest = sum(a for _, a in s["categories"][7:])
        labels = [n for n, _ in top] + (["Other"] if rest else [])
        values = [a for _, a in top] + ([rest] if rest else [])
        fig, ax = plt.subplots(figsize=(7, 7))
        ax.pie(values, labels=labels, autopct="%1.0f%%", startangle=90)
        ax.set_title("Spending by category")
        fig.tight_layout()
        p = out_dir / f"categories_{stamp}.png"
        fig.savefig(p, dpi=120)
        paths.append(p)
        plt.close(fig)

    # 3. running balance
    ordered = sorted(transactions, key=lambda t: (t.date, t.id))
    balance, dates, values = 0.0, [], []
    for t in ordered:
        balance += -t.amount if t.type == EXPENSE else t.amount
        dates.append(t.date)
        values.append(balance)
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(dates, values, color="#2c3e50", linewidth=2)
    ax.axhline(0, color="grey", linewidth=0.8)
    ax.fill_between(dates, values, 0, alpha=0.15)
    ax.set_title("Running balance")
    ax.set_ylabel("Balance")
    fig.autofmt_xdate()
    fig.tight_layout()
    p = out_dir / f"balance_{stamp}.png"
    fig.savefig(p, dpi=120)
    paths.append(p)
    plt.close(fig)

    return paths, None
