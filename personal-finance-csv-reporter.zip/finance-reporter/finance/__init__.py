"""Personal Finance CSV Reporter - core package."""

CURRENCY = "₹"
