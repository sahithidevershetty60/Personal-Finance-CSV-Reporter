"""Totals, averages, trends, warnings and search."""
import statistics
from collections import defaultdict

from .validation import EXPENSE, INCOME


def month_key(tx):
    return tx.date.strftime("%Y-%m")


def summarize(transactions):
    income = [t for t in transactions if t.type == INCOME]
    expenses = [t for t in transactions if t.type == EXPENSE]
    total_in = round(sum(t.amount for t in income), 2)
    total_out = round(sum(t.amount for t in expenses), 2)

    monthly = defaultdict(lambda: {"income": 0.0, "expense": 0.0})
    for t in transactions:
        monthly[month_key(t)][t.type] += t.amount
    months = sorted(monthly)

    by_category = defaultdict(float)
    for t in expenses:
        by_category[t.category] += t.amount
    categories = sorted(by_category.items(), key=lambda kv: kv[1], reverse=True)

    return {
        "count": len(transactions),
        "income_count": len(income),
        "expense_count": len(expenses),
        "total_income": total_in,
        "total_expense": total_out,
        "net": round(total_in - total_out, 2),
        "savings_rate": round((total_in - total_out) / total_in * 100, 1) if total_in else None,
        "avg_income": round(total_in / len(income), 2) if income else 0.0,
        "avg_expense": round(total_out / len(expenses), 2) if expenses else 0.0,
        "avg_monthly_expense": round(total_out / len(months), 2) if months else 0.0,
        "months": months,
        "monthly": {m: {k: round(v, 2) for k, v in monthly[m].items()} for m in months},
        "categories": [(name, round(amt, 2)) for name, amt in categories],
        "largest_expense": max(expenses, key=lambda t: t.amount) if expenses else None,
        "first_date": min((t.date for t in transactions), default=None),
        "last_date": max((t.date for t in transactions), default=None),
    }


def describe_trend(summary):
    """One line comparing the latest month's spending with the one before."""
    months = summary["months"]
    if len(months) < 2:
        return "Not enough months of data to show a trend yet."
    last, prev = months[-1], months[-2]
    now = summary["monthly"][last]["expense"]
    before = summary["monthly"][prev]["expense"]
    if before == 0:
        return f"Spending in {last} was {now:,.2f}; nothing was spent in {prev}."
    change = (now - before) / before * 100
    direction = "up" if change > 0 else "down"
    return f"Spending in {last} is {direction} {abs(change):.1f}% compared with {prev}."


def find_anomalies(transactions, min_group=4, z_limit=2.0):
    """Expenses that are unusually large.

    Categories with at least `min_group` expenses are judged against their own
    average (z-score). Smaller categories fall back to the overall median.
    The second number returned is the z-score, or the multiple of the median.
    """
    groups = defaultdict(list)
    for t in transactions:
        if t.type == EXPENSE:
            groups[t.category].append(t)
    all_amounts = [t.amount for items in groups.values() for t in items]
    typical = statistics.median(all_amounts) if all_amounts else 0
    flagged = []
    for category, items in groups.items():
        if len(items) < min_group:
            # too few entries to judge by category, so compare with the
            # typical expense overall (10x the median counts as unusual)
            for t in items:
                if typical and t.amount >= typical * 10:
                    flagged.append((t, round(t.amount / typical, 1), round(typical, 2)))
            continue
        amounts = [t.amount for t in items]
        mean = statistics.mean(amounts)
        spread = statistics.pstdev(amounts)
        if spread == 0:
            continue
        for t in items:
            z = (t.amount - mean) / spread
            if z >= z_limit:
                flagged.append((t, round(z, 1), round(mean, 2)))
    return sorted(flagged, key=lambda item: item[1], reverse=True)


def build_warnings(transactions, monthly_budget=None, share_limit=40.0):
    """Plain-language alerts for the console and reports."""
    warnings = []
    s = summarize(transactions)
    if not transactions:
        return warnings

    for month in s["months"]:
        m = s["monthly"][month]
        if m["expense"] > m["income"] and m["income"] > 0:
            warnings.append(f"{month}: spent {m['expense']:,.2f}, which is more than the {m['income']:,.2f} earned.")
        if monthly_budget and m["expense"] > monthly_budget:
            over = m["expense"] - monthly_budget
            warnings.append(f"{month}: over the monthly budget by {over:,.2f}.")

    if s["total_expense"]:
        for name, amount in s["categories"]:
            share = amount / s["total_expense"] * 100
            if share >= share_limit:
                warnings.append(f"'{name}' takes up {share:.1f}% of all spending.")

    for tx, z, mean in find_anomalies(transactions):
        warnings.append(f"Unusual {tx.category} expense on {tx.date}: {tx.amount:,.2f} "
                        f"(typical is around {mean:,.2f}).")

    if s["savings_rate"] is not None and s["savings_rate"] < 10:
        warnings.append(f"Overall savings rate is only {s['savings_rate']}%.")
    return warnings


def search(transactions, keyword=None, category=None, tx_type=None, start=None, end=None):
    results = []
    kw = keyword.lower() if keyword else None
    cat = category.lower() if category else None
    for t in transactions:
        if kw and kw not in t.description.lower() and kw not in t.category.lower():
            continue
        if cat and cat != t.category.lower():
            continue
        if tx_type and t.type != tx_type:
            continue
        if start and t.date < start:
            continue
        if end and t.date > end:
            continue
        results.append(t)
    return sorted(results, key=lambda t: (t.date, t.id))
