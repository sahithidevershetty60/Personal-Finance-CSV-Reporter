"""Bulk CSV import with row-by-row error reporting."""
import csv
from datetime import datetime
from pathlib import Path

from .validation import (parse_amount, parse_category, parse_date,
                         parse_description, parse_type)

REQUIRED_COLUMNS = {"date", "type", "category", "amount"}


class ImportResult:
    def __init__(self):
        self.valid = []        # dicts ready for Store.add_many
        self.errors = []       # (line_number, reason)
        self.duplicates = 0
        self.fatal = None      # message if the file itself could not be used


def _key(row):
    return (row["date"], row["type"], row["category"], row["description"].lower(), row["amount"])


def import_csv(path, existing=()):
    result = ImportResult()
    seen = {(t.date, t.type, t.category, t.description.lower(), t.amount) for t in existing}

    try:
        handle = open(Path(path).expanduser(), newline="", encoding="utf-8-sig")
    except FileNotFoundError:
        result.fatal = f"File not found: {path}"
        return result
    except OSError as err:
        result.fatal = f"Could not open file: {err}"
        return result

    with handle:
        try:
            reader = csv.DictReader(handle)
            if not reader.fieldnames:
                result.fatal = "The file is empty."
                return result
            reader.fieldnames = [(name or "").strip().lower() for name in reader.fieldnames]
            missing = REQUIRED_COLUMNS - set(reader.fieldnames)
            if missing:
                result.fatal = "Missing required column(s): " + ", ".join(sorted(missing))
                return result

            for row in reader:
                line = reader.line_num
                if not any((v or "").strip() for v in row.values() if isinstance(v, str)):
                    continue  # blank line
                try:
                    clean = {
                        "date": parse_date(row.get("date")),
                        "type": parse_type(row.get("type")),
                        "category": parse_category(row.get("category")),
                        "description": parse_description(row.get("description") or ""),
                        "amount": parse_amount(row.get("amount")),
                    }
                except ValueError as err:
                    result.errors.append((line, str(err)))
                    continue
                if _key(clean) in seen:
                    result.duplicates += 1
                    continue
                seen.add(_key(clean))
                result.valid.append(clean)
        except (csv.Error, UnicodeDecodeError) as err:
            result.fatal = f"The file could not be read as CSV: {err}"
    return result


def write_error_log(result, source_name, log_path):
    log_path = Path(log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(log_path, "a", encoding="utf-8") as log:
        log.write(f"[{stamp}] import of {source_name}: "
                  f"{len(result.valid)} ok, {len(result.errors)} rejected, "
                  f"{result.duplicates} duplicate(s)\n")
        for line, reason in result.errors:
            log.write(f"    line {line}: {reason}\n")
    return log_path
