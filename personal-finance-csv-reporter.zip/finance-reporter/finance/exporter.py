"""Write summary reports as Markdown, plain text, or CSV."""
import csv
from datetime import datetime
from pathlib import Path

from . import CURRENCY
from .analytics import build_warnings, describe_trend, find_anomalies, summarize


def _money(value):
    return f"{CURRENCY}{value:,.2f}"


def _stamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _lines(transactions, budget):
    s = summarize(transactions)
    rate = f"{s['savings_rate']}%" if s["savings_rate"] is not None else "n/a"
    return s, rate, build_warnings(transactions, budget)


def export_markdown(transactions, out_dir, budget=None):
    s, rate, warns = _lines(transactions, budget)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"summary_{_stamp()}.md"

    out = ["# Personal Finance Summary", ""]
    out.append(f"Generated {datetime.now():%Y-%m-%d %H:%M}. "
               f"Covers {s['first_date']} to {s['last_date']} ({s['count']} transactions).")
    out += ["", "## Totals", "", "| Metric | Value |", "|---|---|",
            f"| Total income | {_money(s['total_income'])} |",
            f"| Total expenses | {_money(s['total_expense'])} |",
            f"| Net | {_money(s['net'])} |",
            f"| Savings rate | {rate} |",
            f"| Average expense | {_money(s['avg_expense'])} |",
            f"| Average monthly spending | {_money(s['avg_monthly_expense'])} |"]
    out += ["", "## Spending by category", "", "| Category | Amount | Share |", "|---|---|---|"]
    for name, amt in s["categories"]:
        share = amt / s["total_expense"] * 100 if s["total_expense"] else 0
        out.append(f"| {name} | {_money(amt)} | {share:.1f}% |")
    out += ["", "## Monthly breakdown", "", "| Month | Income | Expenses | Net |", "|---|---|---|---|"]
    for m in s["months"]:
        d = s["monthly"][m]
        out.append(f"| {m} | {_money(d['income'])} | {_money(d['expense'])} | {_money(d['income'] - d['expense'])} |")
    out += ["", "## Trend", "", describe_trend(s), "", "## Warnings", ""]
    out += [f"- {w}" for w in warns] or ["- None. Nothing looks out of the ordinary."]
    path.write_text("\n".join(out) + "\n", encoding="utf-8")
    return path


def export_text(transactions, out_dir, budget=None):
    """Plain-text audit log: summary followed by every transaction."""
    s, rate, warns = _lines(transactions, budget)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"audit_{_stamp()}.txt"

    out = ["PERSONAL FINANCE AUDIT LOG", f"Generated: {datetime.now():%Y-%m-%d %H:%M:%S}", "=" * 60,
           f"Transactions : {s['count']}",
           f"Total income : {_money(s['total_income'])}",
           f"Total expense: {_money(s['total_expense'])}",
           f"Net          : {_money(s['net'])}",
           f"Savings rate : {rate}", "", "WARNINGS"]
    out += [f"  ! {w}" for w in warns] or ["  none"]
    out += ["", "ALL TRANSACTIONS", "-" * 60]
    for t in sorted(transactions, key=lambda t: (t.date, t.id)):
        out.append(f"#{t.id:<4} {t.date}  {t.type:<8} {t.category:<16} {t.amount:>12,.2f}  {t.description}")
    path.write_text("\n".join(out) + "\n", encoding="utf-8")
    return path


def export_csv(transactions, out_dir, budget=None):
    """Category-level summary as CSV for spreadsheets."""
    s = summarize(transactions)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"summary_{_stamp()}.csv"
    with open(path, "w", newline="", encoding="utf-8") as handle:
        w = csv.writer(handle)
        w.writerow(["section", "name", "amount", "extra"])
        w.writerow(["total", "income", s["total_income"], ""])
        w.writerow(["total", "expense", s["total_expense"], ""])
        w.writerow(["total", "net", s["net"], ""])
        for name, amt in s["categories"]:
            share = round(amt / s["total_expense"] * 100, 1) if s["total_expense"] else 0
            w.writerow(["category", name, amt, f"{share}%"])
        for m in s["months"]:
            d = s["monthly"][m]
            w.writerow(["month", m, round(d["income"] - d["expense"], 2),
                        f"income={d['income']} expense={d['expense']}"])
    return path
