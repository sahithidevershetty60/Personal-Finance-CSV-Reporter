"""Terminal helpers: colours, tables, pagination."""
import os
import sys

from . import CURRENCY

USE_COLOR = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def paint(text, code):
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text


def green(t): return paint(t, "32")
def red(t): return paint(t, "31")
def yellow(t): return paint(t, "33")
def bold(t): return paint(t, "1")
def dim(t): return paint(t, "2")
def cyan(t): return paint(t, "36")


def banner():
    line = "=" * 50
    print(cyan(line))
    print(bold("   PERSONAL FINANCE CSV REPORTER"))
    print(dim("   load, check, summarise and chart your money"))
    print(cyan(line))


def money(value):
    return f"{CURRENCY}{value:,.2f}"


def _clip(text, width):
    return text if len(text) <= width else text[: width - 1] + "…"


def print_transactions(items, page_size=12):
    """Fixed-width table with pagination for long lists."""
    if not items:
        print(dim("  Nothing to show."))
        return
    header = f"{'ID':>4}  {'Date':<10}  {'Type':<7}  {'Category':<15}  {'Amount':>12}  Description"
    rule = "-" * len(header)
    for start in range(0, len(items), page_size):
        print(header)
        print(rule)
        for t in items[start:start + page_size]:
            amt = f"{t.amount:,.2f}"
            amt = green(f"{amt:>12}") if t.type == "income" else red(f"{amt:>12}")
            print(f"{t.id:>4}  {t.date.isoformat():<10}  {t.type:<7}  "
                  f"{_clip(t.category, 15):<15}  {amt}  {_clip(t.description, 28)}")
        shown = min(start + page_size, len(items))
        print(dim(f"  showing {shown} of {len(items)}"))
        if shown < len(items):
            answer = input("  Enter for next page, q to stop: ").strip().lower()
            if answer == "q":
                break
            print()


def print_summary(s, trend, warnings):
    rate = f"{s['savings_rate']}%" if s["savings_rate"] is not None else "n/a"
    print(bold("\nSUMMARY"))
    print(f"  Period            : {s['first_date']} to {s['last_date']}")
    print(f"  Transactions      : {s['count']} ({s['income_count']} income, {s['expense_count']} expense)")
    print(f"  Total income      : {green(money(s['total_income']))}")
    print(f"  Total expenses    : {red(money(s['total_expense']))}")
    net = money(s["net"])
    print(f"  Net               : {green(net) if s['net'] >= 0 else red(net)}")
    print(f"  Savings rate      : {rate}")
    print(f"  Average expense   : {money(s['avg_expense'])}")
    print(f"  Avg monthly spend : {money(s['avg_monthly_expense'])}")
    if s["largest_expense"]:
        t = s["largest_expense"]
        print(f"  Largest expense   : {money(t.amount)} ({t.description or t.category}, {t.date})")

    print(bold("\nSPENDING BY CATEGORY"))
    top = s["categories"][0][1] if s["categories"] else 1
    for name, amount in s["categories"]:
        share = amount / s["total_expense"] * 100
        bar = "#" * max(1, int(amount / top * 25))
        print(f"  {name:<16} {money(amount):>14}  {share:5.1f}%  {bar}")

    print(bold("\nMONTH BY MONTH"))
    print(f"  {'Month':<8} {'Income':>14} {'Expenses':>14} {'Net':>14}")
    for m in s["months"]:
        d = s["monthly"][m]
        print(f"  {m:<8} {d['income']:>14,.2f} {d['expense']:>14,.2f} {d['income'] - d['expense']:>14,.2f}")

    print(bold("\nTREND"))
    print("  " + trend)

    print(bold("\nWARNINGS"))
    if warnings:
        for w in warnings:
            print(yellow("  ! " + w))
    else:
        print(green("  Nothing looks out of the ordinary."))
    print()
